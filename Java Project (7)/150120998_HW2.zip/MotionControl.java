// Student Name: Abdelrahman Zahran.
// Student Number: 150120998.
public abstract interface MotionControl {
	public abstract boolean controlMotion(boolean hasMotion , boolean isDay);
}
