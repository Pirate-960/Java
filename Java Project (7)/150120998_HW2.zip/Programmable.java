// Student Name: Abdelrahman Zahran.
// Student Number: 150120998.
public abstract interface Programmable {
	public abstract void setTimer(int seconds); 
	public abstract void cancelTimer();
	public abstract void runProgram();
}
