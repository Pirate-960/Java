// Student Name: Abdelrahman Zahran.
// Student Number: 150120998.
public abstract interface LocationControl {
	public abstract void onLeave();
	public abstract void onCome();
}
