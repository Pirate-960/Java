// Student Name: Abdelrahman Zahran.
// Student Number: 150120998.
public interface Comparable<SmartCamera> {
public abstract int compareTo(SmartCamera smartCamera); 
}
